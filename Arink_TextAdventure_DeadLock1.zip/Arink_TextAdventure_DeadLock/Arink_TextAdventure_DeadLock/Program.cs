﻿using System.Media;

namespace Arink_TextAdventure_DeadLock
{
    internal class Program
    {
        World world = new World();
        Player player = new Player();
        Interaction interaction = new Interaction();
        Movement movement = new Movement();

        string[] basicInformationForRooms;

        static void Main(string[] args)
        {
            Program p = new Program();
            SoundPlayer sp = new SoundPlayer();
            sp.SoundLocation = AppDomain.CurrentDomain.BaseDirectory + "DungeonSound.wav";
            sp.PlayLooping();
            p.Start();
        }
        
        void Start()
        {
            string welcome = File.ReadAllText("Welcome.txt");
            string infoForTheRooms = File.ReadAllText("InfoForTheRooms.txt");
            basicInformationForRooms = infoForTheRooms.Split('/');
            Console.WriteLine(welcome);
            Console.WriteLine("\nBeter experience with headphones.");
            MainMenu();
        }
        void MainMenu()
        {
            Console.ReadKey(true);
            Console.Clear();
            Console.WriteLine("You wake up in a dark and gloomy place, you see a hole above your head, you try to stant up en go look for a exit.\n");
            Console.WriteLine(basicInformationForRooms[0] + "\n");
            world.rooms.Add(1, new Room());
            world.GetInfoForRooms();
            world.rooms[1].description = "Dit is een test";
            Console.WriteLine(world.rooms[1].description);
            while (true){
                movement.CanMoveTo();
                interaction.InputStart();
            }
        }
    }
}
            //world.GetInfoForRooms();
            //foreach (KeyValuePair<int, Room> item in world.rooms)
            //{
            //    Console.WriteLine($"ID: {item.Key}, Name: {item.Value.name}, Description: {item.Value.description}, {item.Value.canGoNorth}, {item.Value.canGoEast}, {item.Value.canGoSouth}, {item.Value.canGoWest}");
            //}
            //Console.ReadKey(true);