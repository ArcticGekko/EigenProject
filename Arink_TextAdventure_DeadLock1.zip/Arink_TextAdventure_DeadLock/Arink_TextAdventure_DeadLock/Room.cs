﻿namespace Arink_TextAdventure_DeadLock
{
    internal class Room
    {
        public string name;
        public string description;
        public string canGoNorth;
        public string canGoEast;
        public string canGoSouth;
        public string canGoWest;

        public Room(string _Name = "", string _Description = "", string _CanGoNorth = "0", string _CanGoEast = "0", string _CanGoSouth = "0", string _CanGoWest = "0")
        {
            name = _Name;
            description = _Description;
            canGoNorth = _CanGoNorth;
            canGoEast = _CanGoEast;
            canGoSouth = _CanGoSouth;
            canGoWest = _CanGoWest;
        }
    }
}