﻿namespace Arink_TextAdventure_DeadLock
{
    internal class World
    {
        public Dictionary<int, Room> rooms = new Dictionary<int, Room>();
        string basicInformationForRooms = File.ReadAllText("InfoForTheRoomstest.txt");
        List<string> roomsAddSplit = new List<string>();
        string[] roomsSplit;
        string[] roomsInfoSplit;

        public void MakeRoom(int id, string name, string description,
            string canGoNorth, string canGoEast, string canGoSouth, string canGoWest)
        {
            rooms.Add(id, new Room(name, description, canGoNorth, canGoEast, canGoSouth, canGoWest));
        }
        public void GetInfoForRooms()
        {
            roomsSplit = basicInformationForRooms.Split('/');
            
        }
        void GiveInfoToRooms()
        {
            int rekenen1 = 0;
            int rekenen2 = 1;
            int rekenen3 = 2;
            int rekenen4 = 3;
            int rekenen5 = 4;
            int rekenen6 = 5;
            roomsInfoSplit = basicInformationForRooms.Split('.');
            //Console.WriteLine(roomsInfoSplit.Length);
            for (int i = 0; i < roomsInfoSplit.Length; i++)
            {
                //Console.WriteLine(roomsAddSplit[rekenen1] + roomsAddSplit[rekenen2] + roomsAddSplit[rekenen3] + roomsAddSplit[rekenen4] + roomsAddSplit[rekenen5] + roomsAddSplit[rekenen6]);
                MakeRoom(i, roomsAddSplit[rekenen1], roomsAddSplit[rekenen2], roomsAddSplit[rekenen3],
                    roomsAddSplit[rekenen4], roomsAddSplit[rekenen5], roomsAddSplit[rekenen6]);
                rekenen1 += 6;
                rekenen2 += 6;
                rekenen3 += 6;
                rekenen4 += 6;
                rekenen5 += 6;
                rekenen6 += 6;
            }
        }
    }
}
