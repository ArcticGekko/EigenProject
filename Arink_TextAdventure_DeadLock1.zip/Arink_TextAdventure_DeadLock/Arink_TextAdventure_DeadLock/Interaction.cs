﻿namespace Arink_TextAdventure_DeadLock
{
    internal class Interaction
    {
        string input;
        bool inputHasBeenGiven;
        bool wrongInputHasBeenGiven;
        Inventory inventory = new Inventory();
        Player player = new Player();
        Movement movement = new Movement();

        public void InputStart()
        {
            inputHasBeenGiven = false;
            wrongInputHasBeenGiven = false;
            Console.WriteLine("What do you want to do?");
            PlayerInput();
        }
        void PlayerInput()
        {
            input = Console.ReadLine() ?? "".ToLower();
            Console.Clear();
            if (inputHasBeenGiven != true){
                inputHasBeenGiven = true;
                InputOptions();
            }
        }
        void InputOptions()
        {
            if (input.StartsWith("north") || input.StartsWith("noord") || input == "w")
            {
                if (movement.canGoNorth == true)
                {
                    player.playerPos += 11;
                }
                else if (movement.canGoNorth != true)
                {
                    Console.WriteLine("You ran straight into a wall.");
                }
            }
            else if (input.StartsWith("east") || input.StartsWith("oost") || input == "d")
            {
                if (movement.canGoEast == true)
                {
                    player.playerPos += 1;
                }
                else if (movement.canGoEast != true)
                {
                    Console.WriteLine("You ran straight into a wall.");
                }
            }
            else if (input == "s" || input.StartsWith("south") || input.StartsWith("zuid"))
            {
                if (movement.canGoSouth == true)
                {
                    player.playerPos -= 11;
                    if (player.playerPos == 80)
                    {
                        player.playerPos = 47;
                    }
                }
                else if (movement.canGoSouth != true)
                {
                    Console.WriteLine("You ran straight into a wall.");
                }
            }
            else if (input == "a" || input.StartsWith("west")){
                if (movement.canGoWest == true){ 
                    //if (){
                        if (player.playerPos == 47){
                            player.playerPos = 80;
                        }
                        else{
                            player.playerPos -= 1;
                        }
                    //}
                }
                else if (movement.canGoWest != true){
                    Console.WriteLine("You ran straight into a wall.");
                }
            }
            else if (input == "inventory" || input == "inventaris")
            {
                inventory.ShowInventory();
            }
            else if (input == "look")
            {

            }
            else if (input.StartsWith("take"))
            {
                Console.WriteLine("What do you want to Take()?");
                PlayerInput();
                if (input.Contains("sword") /*&& player positie gelijk is aan sword room number && sword nog niet gepakt is*/)
                {
                    inventory.AddToInventory("Sword");
                }
                else if (input.Contains("hammer") /*&& player positie gelijk is aan hammer room number && hammer nog niet gepakt is*/)
                {
                    inventory.AddToInventory("Hammer");
                }
                else if (input.Contains("boots") /*&& player positie gelijk is aan Hi-Jump boots room number && Hi-Jump boots nog niet gepakt is*/)
                {
                    inventory.AddToInventory("Hi-Jump Boots");
                }
                else if (input.Contains("magic") /*&& player positie gelijk is aan magic crystal room number && magic crystal nog niet gepakt is*/)
                {
                    inventory.AddToInventory("Magic Crystal");
                }
                else if (input.Contains("warp") /*&& player positie gelijk is aan warp cloak room number && warp cloak nog niet gepakt is*/)
                {
                    inventory.AddToInventory("Warp Cloak");
                }
                // Nog niet klaar hier
                else if (input.Contains("key"))
                {
                    //if (){ 
                    
                    //}
                    //else if (){ 
                    
                    //}
                    //else if (){ 
                    
                    //}
                }
                else{ 
                    wrongInputHasBeenGiven = true;
                }
            }
            else if (input.StartsWith("use"))
            {
                Console.WriteLine("What do you whant to Use()?");
                PlayerInput();
                if (input.Contains("sword"))
                {
                    if (inventory.inventoryName.Contains("Sword"))
                    {
                        Console.WriteLine("Test sword was used");
                    }
                    else
                    {
                        Console.WriteLine("You don't even got a sword to use.");
                    }
                }
                else if (input.Contains("hammer"))
                {
                    //if (){

                    //}
                    //else{
                    //    Console.WriteLine("You don't even got a hammer to use.");
                    //}
                }
                else if (input.Contains("magic"))
                {
                    //if (){

                    //}
                    //else{
                    //    Console.WriteLine("You havn't learned any magic yet.");
                    //}
                }
                else if (input.Contains("bandage"))
                {

                }
                else if (input.Contains("key"))
                {

                }
                else if (input.Contains("map"))
                {

                }
                else if (input.Contains("crystal")){ 
                    
                }
                else{ 
                    wrongInputHasBeenGiven = true;
                }
            }
            else if (input.Contains("talk")){ 
                
            }
            else if (input.Contains("help"))
            {
                Console.WriteLine("Help for interaction options.");
                Console.WriteLine("\"Help\" ( help ) Shows you most of the interactions.");
                Console.WriteLine("\"Go north\" ( w | north | noord ) Makes te player go to the room north of it if ter is no room north of the player this won't work.");
                Console.WriteLine("\"Go east\" ( d | east | oost ) Makes te player go to the room east of it if ter is no room east of the player this won't work.");
                Console.WriteLine("\"Go south\" ( s | south | zuid ) Makes te player go to the room south of it if ter is no room south of the player this won't work.");
                Console.WriteLine("\"Go west\" ( a | west ) Makes te player go to the room west of it if ter is no room west of the player this won't work.");
                Console.WriteLine("\"Inventory\" ( inventory | inventaris ) Shows the player what you have in your inventory.");
                Console.WriteLine("\"Use\" ( use ) Use a item that you have in your inventory.");
                Console.WriteLine("\"Take\" ( take ) Take a item from a room and add it to your inventory.");
                Console.WriteLine("\"Look\" ( look ) Look for hidden tings in a room.");
                Console.WriteLine("\"Talk\" ( talk ) Talk to sombody.");
            }
            //else if (input == "subscribe"){
            //    Console.WriteLine("You start to look in a direction and ask tem to like and subscribe.....\n.....\n.....\n.....\n.....\nI think you have lost your mind speaking to nobody.");
            //}
            else{
                wrongInputHasBeenGiven = true;
            }
            if (wrongInputHasBeenGiven == true){
                Console.WriteLine("Sorry but that is not a option.\nPlease try somthing else.");
                Console.ReadKey(true);
                Console.Clear();
                InputStart();
            }
            Console.ReadKey(true);
            Console.Clear();
        }
    }
}