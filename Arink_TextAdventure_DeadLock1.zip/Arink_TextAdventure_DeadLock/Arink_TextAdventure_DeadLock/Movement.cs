﻿namespace Arink_TextAdventure_DeadLock
{
    internal class Movement
    {
        Player player = new Player();
        Inventory inventory = new Inventory();

        public bool canGoNorth = false;
        public bool canGoEast = false;
        public bool canGoSouth = false;
        public bool canGoWest = false;
        public bool meetsNorthMovementRequirements = false;
        public bool meetsEastMovementRequirements = false;
        public bool meetsSouthMovementRequirements = false;
        public bool meetsWestMovementRequirements = false;

        int northRequirement = 0;
        int eastRequirement = 0;
        int southRequirement = 0;
        int westRequirement = 0;
        public void CanMoveTo()
        {
            canGoNorth = false;
            canGoEast = false;
            canGoSouth = false;
            canGoWest = false;
            int northRequirement = 0;
            int eastRequirement = 0;
            int southRequirement = 0;
            int westRequirement = 0;
            switch (player.playerPos)
            {
                case 2:
                    canGoEast = true;
                    break;
                case 3:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 4:
                    canGoWest = true;
                    break;
                case 6:
                    canGoNorth = true;
                    break;
                case 7:
                    canGoNorth = true;
                    canGoEast = true;
                    break;
                case 8:
                    canGoNorth = true;
                    canGoWest = true;
                    break;
                case 11:
                    canGoEast = true;
                    break;
                case 12:
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 13:
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 14:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 15:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 16:
                    canGoNorth = true;
                    canGoWest = true;
                    break;
                case 17:
                    canGoNorth = true;
                    canGoSouth = true;
                    break;
                case 18:
                    canGoNorth = true;
                    canGoSouth = true;
                    break;
                case 19:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    break;
                case 20:
                    canGoWest = true;
                    break;
                case 22:
                    canGoEast = true;
                    break;
                case 23:
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 24:
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 25:
                    canGoNorth = true;
                    canGoSouth = true;
                    break;
                case 26:
                    canGoNorth = true;
                    canGoSouth = true;
                    break;
                case 27:
                    canGoNorth = true;
                    canGoSouth = true;
                    break;
                case 28:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    break;
                case 29:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 30:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 31:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 32:
                    canGoNorth = true;
                    canGoWest = true;
                    break;
                case 35:
                    canGoEast = true;
                    break;
                case 36:
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 37:
                    canGoEast = true;
                    canGoSouth = true;
                    break;
                case 38:
                    canGoNorth = true;
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 39:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    break;
                case 40:
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 41:
                    canGoNorth = true;
                    canGoSouth = true;
                    break;
                case 42:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    break;
                case 43:
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 44:
                    canGoEast = true;
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 45:
                    canGoNorth = true;
                    canGoWest = true;
                    break;
                case 47:
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 48:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 49:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 50:
                    canGoNorth = true;
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 52:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    break;
                case 53:
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 56:
                    canGoNorth = true;
                    canGoSouth = true;
                    break;
                case 57:
                    canGoNorth = true;
                    canGoEast = true;
                    break;
                case 58:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 59:
                    canGoNorth = true;
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 60:
                    canGoSouth = true;
                    break;
                case 61:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    break;
                case 62:
                    canGoNorth = true;
                    canGoWest = true;
                    break;
                case 63:
                    canGoSouth = true;
                    break;
                case 66:
                    canGoEast = true;
                    break;
                case 67:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 68:
                    canGoEast = true;
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 69:
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 70:
                    canGoNorth = true;
                    canGoEast = true;
                    canGoSouth = true;
                    break;
                case 71:
                    canGoWest = true;
                    break;
                case 72:
                    canGoEast = true;
                    canGoSouth = true;
                    break;
                case 73:
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 78:
                    canGoEast = true;
                    canGoSouth = true;
                    break;
                case 79:
                    canGoEast = true;
                    canGoWest = true;
                    break;
                case 80:
                    canGoSouth = true;
                    canGoWest = true;
                    break;
                case 81:
                    canGoSouth = true;
                    break;
                default:
                    Console.WriteLine("Error");
                    break;
            }
            HasRequiredItemToMove();
        }
        void HasRequiredItemToMove()
        {
            if (northRequirement == 0)
            {

            }
            else if (northRequirement == 1)
            {
                Console.WriteLine("There are vines blocking the way.");
                if (inventory.inventoryName.Contains("Sword"))
                {
                    Console.WriteLine("You cut a way through the vines with your sword");
                    Console.WriteLine("After getting through te vines they grew right back.");
                }
                else{
                    Console.WriteLine("You can't get through the vines without something sharp");
                    meetsNorthMovementRequirements = false;
                }
            }
            else if (northRequirement == 2)
            {
                if (inventory.inventoryName.Contains("Hammer"))
                {

                }
                else
                {

                }
            }
            else if (northRequirement == 3)
            Console.ReadKey(true);
        }
    }
}