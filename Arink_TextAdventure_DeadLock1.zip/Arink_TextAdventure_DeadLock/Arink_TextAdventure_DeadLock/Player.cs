﻿namespace Arink_TextAdventure_DeadLock
{
    internal class Player
    {
        public int playerPos;
        int playerHp;

        public Player(int _PlayerPos = 22, int _PlayerHp = 10)
        {
            playerPos = _PlayerPos;
            playerHp = _PlayerHp;
        }
    }
}