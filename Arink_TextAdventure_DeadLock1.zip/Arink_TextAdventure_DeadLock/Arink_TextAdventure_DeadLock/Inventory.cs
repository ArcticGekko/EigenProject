﻿namespace Arink_TextAdventure_DeadLock
{
    internal class Inventory
    {
        public List<string> inventoryName = new List<string> {"test1", "test2"};

        public void AddToInventory(string itemName)
        {
            inventoryName.Add(itemName);
            Console.WriteLine($"You acquired the {itemName}.");
        }
        public void ShowInventory()
        {
            foreach (string item in inventoryName)
            {
                Console.WriteLine($"A {item}.");
            }
        }
    }
}
